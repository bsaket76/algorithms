/******************************************************************************
 *  Compilation:  javac Point.java
 *  Execution:    java Point
 *  Dependencies: none
 *
 *  An immutable data type for points in the plane.
 *  For use on Coursera, Algorithms Part I programming assignment.
 *
 ******************************************************************************/

import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

import java.util.Arrays;
import java.util.Comparator;

public class Point implements Comparable<Point> {

    private final int x;     // x-coordinate of this point
    private final int y;     // y-coordinate of this point

    /**
     * Initializes a new point.
     *
     * @param x the <em>x</em>-coordinate of the point
     * @param y the <em>y</em>-coordinate of the point
     */
    public Point(int x, int y) {
        /* DO NOT MODIFY */
        this.x = x;
        this.y = y;
    }

    /**
     * Draws this point to standard draw.
     */
    public void draw() {
        /* DO NOT MODIFY */
        StdDraw.point(x, y);
    }

    /**
     * Draws the line segment between this point and the specified point to standard draw.
     *
     * @param that the other point
     */
    public void drawTo(Point that) {
        /* DO NOT MODIFY */
        StdDraw.line(this.x, this.y, that.x, that.y);
    }

    /**
     * Returns the slope between this point and the specified point. Formally, if the two points are
     * (x0, y0) and (x1, y1), then the slope is (y1 - y0) / (x1 - x0).
     * <p>
     * <p>
     * For completeness, the slope is defined to be:
     * <p>
     * +0.0 if the line segment connecting the two points is horizontal;
     * <p>
     * Double.POSITIVE_INFINITY if the line segment is vertical;
     * <p>
     * Double.NEGATIVE_INFINITY if (x0, y0) and (x1, y1) are equal.
     *
     * @param that the other point
     * @return the slope between this point and the specified point
     */
    public double slopeTo(Point that) {

        //Equal
        if (this.x == that.x && this.y == that.y) {
            return Double.NEGATIVE_INFINITY;
        }

        //Vertical
        if (this.x == that.x && this.y != that.y) {
            return Double.POSITIVE_INFINITY;
        }

        //Horizontal
        if (this.y == that.y && this.x != that.x) {
            return +0.0;
        }
        return ((double) that.y - (double) this.y) / ((double) that.x - (double) this.x);
    }

    /**
     * Compares two points by y-coordinate, breaking ties by x-coordinate.
     * <p>
     * Formally, the invoking point (x0, y0) is less than the argument point (x1, y1) if and only if
     * either y0 < y1 or if y0 = y1 and x0 < x1.
     *
     * @param that the other point
     * @return the value <tt>0</tt> if this point is equal to the argument point (x0 = x1 and y0 =
     * y1); a negative integer if this point is less than the argument point; and a positive integer
     * if this point is greater than the argument point
     */
    public int compareTo(Point that) {
        int thatX = that.x;
        int thatY = that.y;
        if (this.y < thatY) {
            return -1;
        }
        else if (this.y > thatY) {
            return 1;
        }
        //y is euqal so break tie with x
        if (this.x < thatX) {
            return -1;
        }
        else if (this.x > thatX) {
            return 1;
        }
        return 0;
    }


    /**
     * Compares two points by the slope they make with this point. The slope is defined as in the
     * slopeTo() method.
     *
     * @return the Comparator that defines this ordering on points
     */
    public Comparator<Point> slopeOrder() {
        return new SlopeOrder();
    }

    private class SlopeOrder implements Comparator<Point> {

        @Override
        public int compare(Point pointOne, Point pointTwo) {
            double slopeOfFirstToThisPoint = slopeTo(pointOne);
            double slopeOfSecondToThisPoint = slopeTo(pointTwo);

            if (slopeOfFirstToThisPoint < slopeOfSecondToThisPoint) {
                return -1;
            }
            else if (slopeOfFirstToThisPoint > slopeOfSecondToThisPoint) {
                return 1;
            }
            return 0;
        }
    }


    /**
     * Returns a string representation of this point. This method is provide for debugging; your
     * program should not rely on the format of the string representation.
     *
     * @return a string representation of this point
     */
    public String toString() {
        /* DO NOT MODIFY */
        return "(" + x + ", " + y + ")";
    }

    /**
     * Unit tests the Point data type.
     */
    public static void main(String[] args) {
        /* YOUR CODE HERE */

        Point[] points = new Point[5];
        points[0] = new Point(0, -6);
        points[1] = new Point(-1, -6);
        points[2] = new Point(2, 6);
        points[3] = new Point(-1, 1);
        points[4] = new Point(0, 2);

        Arrays.sort(points);

        StdOut.println(Arrays.toString(points));


        StdOut.println("Equals " + new Point(1, 0).compareTo(new Point(1, 0)));
        StdOut.println("Less than " + new Point(1, -1).compareTo(new Point(1, 0)));
        StdOut.println("Greater than " + new Point(1, 1).compareTo(new Point(1, 0)));
        StdOut.println();
        StdOut.println();
        StdOut.println();

        StdOut.println("Equals " + new Point(5, 5).compareTo(new Point(5, 5)));
        StdOut.println("Less than " + new Point(-5, 0).compareTo(new Point(-3, 0)));
        StdOut.println("Greater than " + new Point(9, 1).compareTo(new Point(8, 1)));

        //(10000, 0) AND (0, 10000)
        StdOut.println(new Point(10000, 0).compareTo(new Point(0, 10000)));
        StdOut.println();
        StdOut.println(new Point(10000, 0).slopeTo(new Point(3000, 7000)));
        StdOut.println(new Point(3000, 7000).slopeTo(new Point(7000, 3000)));
        StdOut.println(new Point(3000, 7000).slopeTo(new Point(0, 10000)));
        StdOut.println(new Point(10000, 0).slopeTo(new Point(3000, 7000)));
        StdOut.println(new Point(10000, 0).slopeTo(new Point(7000, 3000)));
        StdOut.println("-----------------------------------------------------------------");
        StdOut.println(new Point(10000, 0).slopeTo(new Point(0, 10000)));
        StdOut.println(new Point(10000, 0).compareTo(new Point(0, 10000)));
        StdOut.println("-----------------------------------------------------------------");
        StdOut.println(new Point(493, 384).slopeTo(new Point(301, 384)));
        StdOut.println(new Point(9, 8).slopeTo(new Point(9, 7)));

        StdOut.println("-----------------------------------------------------------------\n\n\n");
        StdOut.println(
                new Point(394, 233).slopeOrder().compare(new Point(59, 5), new Point(306, 53)));

        //(10000, 0) -> (13000, 0) -> (20000, 0) -> (30000, 0)
        Point p0 = new Point(10000, 0);
        Point p1 = new Point(13000, 0);
        Point p2 = new Point(20000, 0);
        Point p3 = new Point(30000, 0);

        StdOut.println("p0.slopeTo(p1) " + p0.slopeTo(p1));
        StdOut.println("p1.slopeTo(p2) " + p1.slopeTo(p2));
        StdOut.println("p2.slopeTo(p3) " + p2.slopeTo(p3));

        Point[] pointsArray = new Point[] {
                new Point(400, 0),
                new Point(10, 50),
                new Point(100, 0),
                new Point(10, 60),
                new Point(300, 0),
                new Point(10, 70),
                new Point(200, 0)
        };


        Point[] clone;
        for (int i = 0; i < pointsArray.length; i++) {
            clone = cloneArray(pointsArray);
            Point referencePoint = clone[i];
            Arrays.sort(clone, clone[i].slopeOrder());
            for (int j = 0; j < clone.length; j++) {
                Point nextPoint = clone[j];
                if (referencePoint.compareTo(nextPoint) == 0) {
                    continue;
                }
                StdOut.println(
                        "\tSlope with " + nextPoint + " is " + referencePoint.slopeTo(nextPoint));
            }
            StdOut.println();

        }

        StdOut.println();
        StdOut.println();
        StdOut.println("p0.compareTo(p1) " + p0.compareTo(p1));
        StdOut.println("p1.compareTo(p2) " + p1.compareTo(p2));
        StdOut.println("p2.compareTo(p3) " + p2.compareTo(p3));

        StdOut.println("********************");
        StdOut.println(new Point(3000, 4000).slopeTo(new Point(20000, 21000)));
        StdOut.println(new Point(3000, 4000).slopeTo(new Point(0, 10000)));


        // (0, 50) second: (0, 75) third: (0, 100) fourth: (0, 200)
        Point aa = new Point(0, 50);
        Point bb = new Point(0, 75);
        Point cc = new Point(0, 100);
        Point dd = new Point(0, 200);

        StdOut.println("aa.slopeTo(bb): " + aa.slopeTo(bb));
        StdOut.println("cc.slopeTo(dd): " + cc.slopeTo(dd));
        StdOut.println("aa.slopeTo(bb) == cc.slopeTo(dd): " + (aa.slopeTo(bb) == cc.slopeTo(dd)));

        StdOut.println(new Point(10000, 0).slopeTo(new Point(0, 10000)));
        StdOut.println(new Point(30000, 0).slopeTo(new Point(0, 30000)));


        Point somePointOne = new Point(14407, 10367);
        Point somePointTwo = new Point(14407, 19953);
        Point somePointThree = new Point(15976, 3370);
        Point somePointFour = new Point(15976, 9945);
        StdOut.println(somePointOne.slopeTo(somePointTwo));
        StdOut.println(somePointThree.slopeTo(somePointFour));

        Point[] newPointsArray = new Point[]{somePointOne, somePointTwo, somePointThree, somePointFour};
        Arrays.sort(newPointsArray, somePointOne.slopeOrder());
        StdOut.println(Arrays.toString(newPointsArray));
        StdOut.println(">>>" + newPointsArray[3].slopeTo(newPointsArray[1]));
        StdOut.println(newPointsArray[1].slopeTo(newPointsArray[2]));
        StdOut.println(newPointsArray[2].slopeTo(newPointsArray[3]));

        Point[] newPointsArrayOne = new Point[]{new Point(20, 20), new Point(30, 30), new Point(4, 4), new Point(5, 5)};
        Arrays.sort(newPointsArrayOne, newPointsArrayOne[0].slopeOrder());
        StdOut.println(Arrays.toString(newPointsArrayOne));
        StdOut.println(">>>" + newPointsArrayOne[3].slopeTo(newPointsArrayOne[1]));
        StdOut.println(newPointsArrayOne[1].slopeTo(newPointsArrayOne[2]));
        StdOut.println(newPointsArrayOne[2].slopeTo(newPointsArrayOne[3]));




    }


    private static Point[] cloneArray(Point[] input) {
        Point[] result = new Point[input.length];
        for (int i = 0; i < input.length; i++) {
            result[i] = input[i];
        }
        return result;
    }
}
