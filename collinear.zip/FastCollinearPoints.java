/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class FastCollinearPoints {

    private final List<LineSegment> lineSegmentList;
    private final List<List<Point>> possibleCoOrdinatesWithSameSlopeLists = new ArrayList<>();
    private final List<List<Point>> finalEndPointsList = new ArrayList<>();

    // finds all line segments containing 4 or more points
    public FastCollinearPoints(Point[] points) {

        validateInput(points);

        Point[] clone;
        for (int i = 0; i < points.length; i++) {
            clone = cloneArray(points);
            Arrays.sort(clone, clone[i].slopeOrder());
            Point startPoint = clone[0];
            possibleCoOrdinatesWithSameSlopeLists.clear();

            for (int j = 1; j < clone.length; j++) {
                Point nextPoint = clone[j];
                comparePoints(startPoint, nextPoint);
                double nextPointSlope = startPoint.slopeTo(nextPoint);
                boolean matchingSlopeFound = false;
                Iterator<List<Point>> iterator = possibleCoOrdinatesWithSameSlopeLists.iterator();
                int counter = 0;
                while (iterator.hasNext()) {
                    List<Point> existingListOfPoints = iterator.next();
                    double existingSlope = startPoint.slopeTo(existingListOfPoints.get(0));
                    if (!existingListOfPoints.isEmpty() && existingSlope == nextPointSlope) {
                        matchingSlopeFound = true;
                        existingListOfPoints.add(nextPoint);
                        possibleCoOrdinatesWithSameSlopeLists.set(counter, existingListOfPoints);
                        break;
                    }
                    counter++;
                }

                if (!matchingSlopeFound) {
                    List<Point> listOfPointsWithASlope = new ArrayList<>();
                    listOfPointsWithASlope.add(nextPoint);
                    possibleCoOrdinatesWithSameSlopeLists.add(listOfPointsWithASlope);
                }
            }

            boolean isExistingEntryModified = false;
            boolean isMatchingSlopeFound = false;
            boolean isIdentical = false;
            for (List<Point> listOfPoints : possibleCoOrdinatesWithSameSlopeLists) {
                if (listOfPoints.size() < 3) {
                    continue;
                }
                listOfPoints.add(startPoint);
                Collections.sort(listOfPoints);
                Point finalStartForThisLoop = listOfPoints.get(0);
                Point finalEndForThisLoop = listOfPoints.get(listOfPoints.size() - 1);
                double slopeForThisLoop = finalStartForThisLoop.slopeTo(finalEndForThisLoop);

                int finalEndPointsCounter = 0;
                boolean isCollinear = false;
                Iterator<List<Point>> finalEndPointsIterator = finalEndPointsList.iterator();
                while (finalEndPointsIterator.hasNext()) {
                    List<Point> endPointsListForThisIteration = finalEndPointsIterator.next();
                    if (!endPointsListForThisIteration.isEmpty()) {

                        Point existingMin = endPointsListForThisIteration.get(0);
                        Point existingMax = endPointsListForThisIteration.get(1);
                        double existingSlope = existingMin.slopeTo(existingMax);
/*
                        StdOut.println(" *****    possibleCoOrdinatesWithSameSlopeLists "
                                               + possibleCoOrdinatesWithSameSlopeLists + "\n" +
                                               "  existingMin  " + existingMin +
                                               "  existingMax " + existingMax + "\n" +
                                               "  finalStartForThisLoop " + finalStartForThisLoop
                                               + "\n" +
                                               "  finalEndForThisLoop " + finalEndForThisLoop + "\n"
                                               +
                                               "  slopeForThisLoop " + slopeForThisLoop +
                                               "  existingSlope " + existingSlope
                                               + "\n\n\n\n\n\n\n\n");
*/

                        if (slopeForThisLoop == existingSlope) {
                            isMatchingSlopeFound = true;

                            if (finalStartForThisLoop.compareTo(existingMin) == 0
                                    && finalEndForThisLoop.compareTo(existingMax) == 0) {
                                isIdentical = true;
                                continue;
                            }


                            Point[] collinearCheckArray = new Point[] {
                                    existingMin, existingMax, finalStartForThisLoop,
                                    finalEndForThisLoop
                            };
                            Arrays.sort(collinearCheckArray, collinearCheckArray[0].slopeOrder());
                            if ((collinearCheckArray[1].slopeTo(collinearCheckArray[2])
                                    == collinearCheckArray[2].slopeTo(collinearCheckArray[3]))
                                    && (collinearCheckArray[2].slopeTo(collinearCheckArray[3])
                                    == collinearCheckArray[0].slopeTo(collinearCheckArray[1]))) {
                                isCollinear = true;
                            }

                            if (finalStartForThisLoop.compareTo(existingMin) < 0 && isCollinear) {
                                endPointsListForThisIteration.set(0, finalStartForThisLoop);
                                finalEndPointsList
                                        .set(finalEndPointsCounter, endPointsListForThisIteration);
                                isExistingEntryModified = true;
                            }
                            if (finalEndForThisLoop.compareTo(existingMax) > 0 && isCollinear) {
                                endPointsListForThisIteration.set(1, finalEndForThisLoop);
                                finalEndPointsList
                                        .set(finalEndPointsCounter, endPointsListForThisIteration);
                                isExistingEntryModified = true;
                            }
                        }
                    }
                }
/*
                StdOut.println(
                        "finalStartForThisLoop " + finalStartForThisLoop + " finalEndForThisLoop "
                                + finalEndForThisLoop);
                StdOut.println("isMatchingSlopeFound " + isMatchingSlopeFound + " isCollinear "
                                       + isCollinear + " isExistingEntryModified "
                                       + isExistingEntryModified);
                StdOut.println("\t " + finalEndPointsList);
                StdOut.println("\n\n\n");
*/
                if (!isMatchingSlopeFound || (isMatchingSlopeFound && !isCollinear
                        && !isExistingEntryModified && !isIdentical)) {
                    List<Point> newEntryList = new ArrayList<>();
                    newEntryList.add(finalStartForThisLoop);
                    newEntryList.add(finalEndForThisLoop);
                    finalEndPointsList.add(newEntryList);
                }
            }

        }
        lineSegmentList = new ArrayList<>();
        for (List<Point> finalCoordinatesList : finalEndPointsList) {
            lineSegmentList.add(new LineSegment(finalCoordinatesList.get(0),
                                                finalCoordinatesList.get(1)));
        }
    }

    private static void validateInput(Point[] points) {
        if (points == null || points.length == 0) {
            throw new IllegalArgumentException("Points array cannot be empty");
        }
        for (int i = 0; i < points.length; i++) {
            if (points[i] == null) {
                throw new IllegalArgumentException("Point object cannot be null");
            }
        }
    }

    private static void comparePoints(Point one, Point two) {
        if (one.compareTo(two) == 0) {
            throw new IllegalArgumentException(
                    "Two input points cannot be same: " + one + " " + two);
        }
    }

    private static Point[] cloneArray(Point[] input) {
        Point[] result = new Point[input.length];
        for (int i = 0; i < input.length; i++) {
            result[i] = input[i];
        }
        return result;
    }

    // the number of line segments
    public int numberOfSegments() {
        return lineSegmentList.size();
    }


    // the line segments
    public LineSegment[] segments() {
        return lineSegmentList.toArray(new LineSegment[0]);
    }


    public static void main(String[] args) {

        // read the n points from a file
        In in = new In(args[0]);
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
            if (points[i] == null) {
                throw new IllegalArgumentException("Point object cannot be null");
            }
        }

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();

        // print and draw the line segments
        FastCollinearPoints collinear = new FastCollinearPoints(points);
        for (LineSegment segment : collinear.segments()) {
            StdOut.println("Printing lineSegment: " + segment);
            segment.draw();
        }
        StdDraw.show();

    }

}
