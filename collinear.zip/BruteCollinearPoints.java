/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;


/**
 * Performance requirement: -  N^4 in the worst case -  Space proportional to n plus the number of
 * line segments returned
 * <p>
 * Throw java.lang.IllegalArgumentException if: - Argument to the constructor is null - Any point in
 * the array is null - Argument to the constructor contains a repeated point
 */
public class BruteCollinearPoints {

    private LineSegment[] lineSegments;
    private List<List<Point>> endPointsList = new ArrayList<>();

    // finds all line segments containing 4 points
    public BruteCollinearPoints(Point[] points) {
        validateInput(points);

        for (int first = 0; first < points.length; first++) {
            for (int second = 0; second < points.length; second++) {
                if (second == first) {
                    continue;
                }
                comparePoints(points[first], points[second]);
                for (int third = 0; third < points.length; third++) {
                    if (third == second || third == first) {
                        continue;
                    }
                    comparePoints(points[second], points[third]);
                    if (!areSlopesSame(points[first], points[second], points[third])) {
                        continue;
                    }
                    for (int fourth = 0; fourth < points.length; fourth++) {

                        if (fourth == third || fourth == second || fourth == first) {
                            continue;
                        }
                        comparePoints(points[third], points[fourth]);

                        if (areSlopesSame(points[second], points[third], points[fourth]) &&
                                (arePointsAscending(points[first], points[second], points[third],
                                                    points[fourth]))) {
/*
                            StdOut.println("\t Ascending points " + points[first]
                                                   + " " + points[second]
                                                   + " " + points[third]
                                                   + " " + points[fourth]);
*/
                            Point currentMin = points[first];
                            Point currentMax = points[fourth];
                            double currentSlope = currentMin.slopeTo(currentMax);
                            boolean isMatchingSlopeFound = false;
                            boolean isCollinear = false;
                            int counter = 0;
                            Iterator<List<Point>> iterator = endPointsList.iterator();
                            while (iterator.hasNext()) {
                                List<Point> savedEndPointsList = iterator.next();
                                if (savedEndPointsList != null && !savedEndPointsList
                                        .isEmpty()) {
                                    Point savedMin = savedEndPointsList.get(0);
                                    Point savedMax = savedEndPointsList.get(1);
/*
                                    StdOut.println("\t\t\t\nsavedMin " + savedMin
                                                           + " savedMax  " + savedMax
                                                           + " savedSlope "
                                                           + savedMin.slopeTo(savedMax) + "\n"
                                                           + " currentMin " + currentMin
                                                           + " currentMax " + currentMax
                                                           + " currentSlope "
                                                           + currentMin.slopeTo(currentMax)
                                                           + "\n"
                                                           + " endPointsList: " + endPointsList
                                                           + "\n\n\n");
*/
                                    if (savedMin != null && savedMax != null) {
                                        double savedSlope = savedMin.slopeTo(savedMax);

                                        if (currentSlope == savedSlope) {
                                            isMatchingSlopeFound = true;

                                            Point[] collinearCheckArray = new Point[] {
                                                    savedMin, savedMax, currentMin, currentMax
                                            };
                                            Arrays.sort(collinearCheckArray, collinearCheckArray[0].slopeOrder());
                                            if ((collinearCheckArray[1].slopeTo(collinearCheckArray[2])
                                            == collinearCheckArray[2].slopeTo(collinearCheckArray[3]))
                                            && (collinearCheckArray[2].slopeTo(collinearCheckArray[3])
                                                    == collinearCheckArray[0].slopeTo(collinearCheckArray[1]))) {
                                                isCollinear = true;
                                            }

                                            if (currentMin.compareTo(savedMin) < 0 && isCollinear) {
                                                savedEndPointsList.set(0, currentMin);
                                                endPointsList.set(counter, savedEndPointsList);
                                            }
                                            if (currentMax.compareTo(savedMax) > 0 && isCollinear) {
                                                savedEndPointsList.set(1, currentMax);
                                                endPointsList.set(counter, savedEndPointsList);
                                            }
                                        }
                                    }
                                }
                                counter++;
                            }
                            if (!isMatchingSlopeFound || (isMatchingSlopeFound && !isCollinear)) {
                                /*
                                StdOut.println("Added blanket net entry with " + currentMin + "  "
                                                       + currentMax);
                                */
                                List<Point> newEntry = new ArrayList<>();
                                newEntry.add(currentMin);
                                newEntry.add(currentMax);
                                endPointsList.add(newEntry);
                            }
                        }
                    }
                }
            }
        }
        int lineSegmentCounter = 0;
        lineSegments = new LineSegment[endPointsList.size()];
        for (List<Point> entriesList : endPointsList) {
            Point finalMin = entriesList.get(0);
            Point finalMax = entriesList.get(1);
            if (finalMin != null && finalMax != null) {
                lineSegments[lineSegmentCounter++] = new LineSegment(finalMin, finalMax);
            }
        }
    }


    private boolean areSlopesSame(Point firstPoint, Point secondPoint, Point thirdPoint) {
        return firstPoint.slopeTo(secondPoint) == secondPoint.slopeTo(thirdPoint);
    }


    private boolean arePointsAscending(Point p1, Point p2, Point p3, Point p4) {
        return (p1.compareTo(p2) < 0 && p2.compareTo(p3) < 0 && p3.compareTo(p4) < 0);
    }

    private void comparePoints(Point firstPoint, Point secondPoint) {
        if (firstPoint.compareTo(secondPoint) == 0) {
            throw new IllegalArgumentException(
                    "Two input points cannot be same: " + firstPoint + " " + secondPoint);
        }
    }


    private void validateInput(Point[] points) {
        if (points == null || points.length == 0) {
            throw new IllegalArgumentException("Points array cannot be empty");
        }
        for (int i = 0; i < points.length; i++) {
            if (points[i] == null) {
                throw new IllegalArgumentException("Point object cannot be null");
            }
        }
    }

    // the number of line segments
    public int numberOfSegments() {
        return actualLengthOfLineSegments();
    }

    // the line segments
    public LineSegment[] segments() {

        LineSegment[] result = new LineSegment[actualLengthOfLineSegments()];
        int index = 0;
        for (LineSegment ls : lineSegments) {
            if (ls != null) {
                result[index++] = ls;
            }
        }
        return result;
    }

    private int actualLengthOfLineSegments() {
        int length = 0;
        for (LineSegment ls : lineSegments) {
            if (ls != null) {
                length++;
            }
        }
        return length;
    }


    public static void main(String[] args) {

        In in = new In(args[0]);
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();

        // print and draw the line segments
        BruteCollinearPoints collinear = new BruteCollinearPoints(points);
        for (LineSegment segment : collinear.segments()) {
            StdOut.println("Printing lineSegment: " + segment);
            segment.draw();
        }
        StdDraw.show();


    }
}
