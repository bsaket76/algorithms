import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.Stack;
import edu.princeton.cs.algs4.StdOut;

/******************************************************************************
 *  Compilation:  javac-algs4 PuzzleChecker.java
 *  Execution:    java-algs4 PuzzleChecker filename1.txt filename2.txt ...
 *  Dependencies: Board.java Solver.java
 *
 *  This program creates an initial board from each filename specified
 *  on the command line and finds the minimum number of moves to
 *  reach the goal state.
 *
 *  % java-algs4 PuzzleChecker puzzle*.txt
 *  puzzle00.txt: 0
 *  puzzle01.txt: 1
 *  puzzle02.txt: 2
 *  puzzle03.txt: 3
 *  puzzle04.txt: 4
 *  puzzle05.txt: 5
 *  puzzle06.txt: 6
 *  ...
 *  puzzle3x3-impossible: -1
 *  ...
 *  puzzle42.txt: 42
 *  puzzle43.txt: 43
 *  puzzle44.txt: 44
 *  puzzle45.txt: 45
 *
 ******************************************************************************/

public class Solver {

    private final Node initialNodeOriginal;

    private Node goalNode;
    private Stack<Board> solutionStack;


    private boolean isOriginalBoardSolvable = false;

    private class Node implements Comparable<Node> {
        Board board;
        Node parent;
        int movesToReachThisBoard;
        int manhattanDistance;

        Node(Board board, Node parent, int movesToReach) {
            if (board == null) {
                throw new IllegalArgumentException("Board cannot be null");
            }
            if(parent != null && parent.board == null) {
                throw new IllegalArgumentException("Parent Board cannot be null");
            }
            this.board = board;
            this.parent = parent;
            this.movesToReachThisBoard = movesToReach;
            this.manhattanDistance = this.board.manhattan();
        }

        @Override
        public int compareTo(Node that) {
            int thisManhattanPlusMoves = this.manhattanDistance + this.movesToReachThisBoard;
            int thatManhattanPlusMoves = that.manhattanDistance + that.movesToReachThisBoard;
            return thisManhattanPlusMoves - thatManhattanPlusMoves;
        }

        @Override
        public String toString() {
            return "[\n" +
                    "thisNodeBoard " + board
                    + "\n\tparentNode " + parent
                    + "\n\t  movesToReachThisBoard " + movesToReachThisBoard
                    + "\n\n]";
        }
    }


    // find a solution to the initial board (using the A* algorithm)
    public Solver(Board initialBoard) {

        if(initialBoard == null) {
            throw new IllegalArgumentException("Board cannot be null");
        }

        Board twinBoard = initialBoard.twin();

        MinPQ<Node> minPQ;
        MinPQ<Node> minPQTwin;

        Node rootNode = new Node(initialBoard, null, 0);
        Node rootNodeTwin = new Node(twinBoard, null, 0);

        this.initialNodeOriginal = rootNode;

        minPQ = new MinPQ<>();
        minPQTwin = new MinPQ<>();

        minPQ.insert(rootNode);
        minPQTwin.insert(rootNodeTwin);

        Node minNode = minPQ.delMin();
        Node minNodeTwin = minPQTwin.delMin();

        while ((minNode != null && !minNode.board.isGoal()) &&
                (minNodeTwin != null && !minNodeTwin.board.isGoal())) {
            Board parentBoard = minNode.parent != null ? minNode.parent.board : null;
            Iterable<Board> neighborBoards = minNode.board.neighbors();
            for (Board neighborBoard : neighborBoards) {
                if (!neighborBoard.equals(parentBoard)) {
                    minPQ.insert(new Node(neighborBoard, minNode, minNode.movesToReachThisBoard + 1));
                }
            }

            Board parentBoardTwin = minNodeTwin.parent != null ? minNodeTwin.parent.board : null;
            Iterable<Board> neighborBoardsTwin = minNodeTwin.board.neighbors();
            for (Board neighborBoardTwin : neighborBoardsTwin) {
                if (!neighborBoardTwin.equals(parentBoardTwin)) {
                    minPQTwin.insert(new Node(neighborBoardTwin, minNodeTwin, minNodeTwin.movesToReachThisBoard + 1));
                }
            }
            minNode = minPQ.delMin();
            minNodeTwin = minPQTwin.delMin();
        }

        if (minNode != null && minNode.board.isGoal()) {
            isOriginalBoardSolvable = true;
            goalNode = minNode;
        } else if (minNodeTwin != null && minNodeTwin.board.isGoal()) {
            goalNode = minNodeTwin;
        }

    }


    // is the initial board solvable?
    public boolean isSolvable() {
        return isOriginalBoardSolvable;
    }


    // min number of moves to solve initial board; -1 if unsolvable
    public int moves() {
        return isSolvable() ? goalNode.movesToReachThisBoard : -1;
    }


    // sequence of boards in a shortest solution; null if unsolvable
    public Iterable<Board> solution() {
        if (solutionStack != null) {
            return solutionStack;
        }
        solutionStack = new Stack<>();
        if (isSolvable()) {
            Node goalNodeCopy = goalNode;
            while (goalNodeCopy != null && goalNodeCopy.parent != null &&
                    !goalNodeCopy.board.equals(initialNodeOriginal.board)) {
                solutionStack.push(goalNodeCopy.board);
                goalNodeCopy = goalNodeCopy.parent;
            }
            solutionStack.push(initialNodeOriginal.board);
            return solutionStack;
        }
        return null;
    }


    // solve a slider puzzle (given below)
    public static void main(String[] args) {

        // create initial board from file
        In in = new In(args[0]);
        int n = in.readInt();

        int[][] blocks = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++) {
                blocks[i][j] = in.readInt();
            }

        Board initial = new Board(blocks);

        // solve the puzzle
        Solver solver = new Solver(initial);

        // print solution to standard output
        if (!solver.isSolvable())
            StdOut.println("No solution possible");
        else {
            StdOut.println("Minimum number of moves = " + solver.moves());
            for (Board board : solver.solution())
                StdOut.println(board);
        }

    }


}
