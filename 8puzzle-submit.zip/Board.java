import edu.princeton.cs.algs4.Queue;
import edu.princeton.cs.algs4.StdOut;

import java.util.Arrays;
import java.util.Iterator;

/******************************************************************************
 *  Compilation:  javac-algs4 PuzzleChecker.java
 *  Execution:    java-algs4 PuzzleChecker filename1.txt filename2.txt ...
 *  Dependencies: Board.java Solver.java
 *
 *  This program creates an initial board from each filename specified
 *  on the command line and finds the minimum number of moves to
 *  reach the goalBlocks state.
 *
 *  % java-algs4 PuzzleChecker puzzle*.txt
 *  puzzle00.txt: 0
 *  puzzle01.txt: 1
 *  puzzle02.txt: 2
 *  puzzle03.txt: 3
 *  puzzle04.txt: 4
 *  puzzle05.txt: 5
 *  puzzle06.txt: 6
 *  ...
 *  puzzle3x3-impossible: -1
 *  ...
 *  puzzle42.txt: 42
 *  puzzle43.txt: 43
 *  puzzle44.txt: 44
 *  puzzle45.txt: 45
 *
 ******************************************************************************/

public class Board {

    private final int[][] inputBlocks;

    private int emptyXPosition = 0;
    private int emptyYPosition = 0;
    private int hammingPriority = -1;
    private int manhattanPriority = -1;


    /**
     * Construct a board from an n-by-n array of inputBlocks (where inputBlocks[i][j] = block in row i, column j)
     */
    public Board(int[][] inputBlocks) {

        if (inputBlocks == null || inputBlocks.length == 0 || inputBlocks[0].length == 0) {
            throw new IllegalArgumentException("Board cannot be empty or null");
        }
        this.inputBlocks = this.copyBoardAndTrackEmptyPosition(inputBlocks);
    }


    private int calculateHamming() {
        if (this.hammingPriority == -1) {
            int size = this.inputBlocks.length;
            int[][] goalBlocks = this.buildGoalBlocks(this.inputBlocks);
            int outOfPlaceCount = 0;
            for (int row = 0; row < size; row++) {
                for (int col = 0; col < size; col++) {
                    if (this.inputBlocks[row][col] == 0) {
                        continue;
                    }
                    if (this.inputBlocks[row][col] != goalBlocks[row][col]) {
                        outOfPlaceCount++;
                    }
                }
            }
            this.hammingPriority = outOfPlaceCount;
        }
        return this.hammingPriority;

    }

    private int calculateManhattan() {
        int manhattanSum = 0;
        boolean isFound = false;
        int[][] goalBlocks = this.buildGoalBlocks(this.inputBlocks);
        int size = this.inputBlocks.length;
        for (int row = 0; row < size; row++) {
            for (int col = 0; col < size; col++) {
                int value = this.inputBlocks[row][col];
                if (value == 0) {
                    continue;
                }
                for (int goalRow = 0; goalRow < size; goalRow++) {
                    for (int goalCol = 0; goalCol < size; goalCol++) {
                        if (goalBlocks[goalRow][goalCol] == value) {
                            manhattanSum += Math.abs(row - goalRow) + Math.abs(col - goalCol);
                            isFound = true;
                            break;
                        }
                    }
                    if (isFound) {
                        isFound = false;
                        break;
                    }
                }
            }
        }
        return manhattanSum;
    }

    private int[][] buildGoalBlocks(int[][] blocks) {
        int[] oneDBlock = convertToOneDAndSort(blocks);
        return build2DBlockFrom1D(oneDBlock);
    }

    private int[] convertToOneDAndSort(int[][] input) {
        int[] oneDBlock = new int[this.dimension() * this.dimension()];
        int counter = 0;
        int length = input.length;
        for (int row = 0; row < length; row++) {
            for (int col = 0; col < length; col++) {
                if (input[row][col] == 0) {
                    oneDBlock[counter++] = Integer.MAX_VALUE;
                } else {
                    oneDBlock[counter++] = input[row][col];
                }
            }
        }
        Arrays.sort(oneDBlock);
        for (int i = 0; i < oneDBlock.length; i++) {
            if (oneDBlock[i] == Integer.MAX_VALUE) {
                oneDBlock[i] = 0;
            }
        }
        return oneDBlock;
    }

    private int[][] build2DBlockFrom1D(int[] oneDBlock) {
        int[][] goalBlock = new int[this.dimension()][this.dimension()];
        int row = 0;
        int col = 0;
        for (int i = 0; i < this.dimension() * this.dimension(); i++) {
            if (col >= this.dimension()) {
                col = 0;
                row++;
            }
            goalBlock[row][col++] = oneDBlock[i];
        }
        return goalBlock;
    }

    /**
     * board dimension n
     */
    public int dimension() {
        return this.inputBlocks.length;
    }

    /**
     * Number of inputBlocks out of place
     * Hamming defn: The number of inputBlocks in the wrong position, plus the number of moves made so far to get to the search node
     */
    public int hamming() {
        if (this.hammingPriority == -1) {
            this.hammingPriority = this.calculateHamming();
        }
        return this.hammingPriority;
    }


    /**
     * Sum of Manhattan distances between inputBlocks and goalBlocks
     * Manhattan distance definition: Sum of the horizontal and vertical distances between points on a grid
     */
    public int manhattan() {
        if (this.manhattanPriority == -1) {
            this.manhattanPriority = calculateManhattan();
        }
        return this.manhattanPriority;
    }

    /**
     * Is this board the goalBlocks board?
     */
    public boolean isGoal() {
        int[][] goalBlocks = this.buildGoalBlocks(this.inputBlocks);
        return deepCompareBlocks(goalBlocks);
    }

    /**
     * Board that is obtained by exchanging any pair of non-empty inputBlocks
     */
    public Board twin() {
        int[][] twinBoard = copyBoard(this.inputBlocks);
        int[] swapCoordinates = this.getOffsetBasedNonEmptyCoordinate();
        swap(twinBoard, swapCoordinates[0], swapCoordinates[1], swapCoordinates[2], swapCoordinates[3]);
        return new Board(twinBoard);
    }


    private int[] getOffsetBasedNonEmptyCoordinate() {
        int[] rowColumnIndices = new int[4];
        int findIndex = 0;
        int size = this.inputBlocks.length;
        for (int row = 0; row < size && findIndex < 4; row++) {
            for (int col = 0; col < size && findIndex < 4; col++) {
                if (row == this.emptyXPosition && col == this.emptyYPosition) {
                    continue;
                }
                rowColumnIndices[findIndex++] = row;
                rowColumnIndices[findIndex++] = col;
            }
        }
        return rowColumnIndices;
    }


    /**
     * Swap the contents at the specified locations for the provided input
     */
    private void swap(int[][] data, int fromX, int fromY, int toX, int toY) {
        int temp = data[fromX][fromY];
        data[fromX][fromY] = data[toX][toY];
        data[toX][toY] = temp;
    }


    /**
     * Deep-clone board and track the empty co-ordinates
     */
    private int[][] copyBoardAndTrackEmptyPosition(int[][] inputBoard) {
        int inputSize = inputBoard.length;
        int[][] clonedBoard = new int[inputSize][inputSize];
        for (int row = 0; row < inputSize; row++) {
            for (int col = 0; col < inputSize; col++) {
                if (inputBoard[row][col] == 0) {
                    this.emptyXPosition = row;
                    this.emptyYPosition = col;
                }
                clonedBoard[row][col] = inputBoard[row][col];
            }
        }
        return clonedBoard;
    }

    private int[][] copyBoard(int[][] inputBoard) {
        int inputSize = inputBoard.length;
        int[][] clonedBoard = new int[inputSize][inputSize];
        for (int row = 0; row < inputSize; row++) {
            for (int col = 0; col < inputSize; col++) {
                clonedBoard[row][col] = inputBoard[row][col];
            }
        }
        return clonedBoard;
    }

    /**
     * Does this board equal y?
     */
    @Override
    public boolean equals(Object y) {
        if (y == null) {
            return false;
        }
        if (y.getClass() != this.getClass()) {
            return false;
        }
        if (y == this) {
            return true;
        }
        Board other = (Board) y;
        if (other.dimension() != this.dimension()) {
            return false;
        }
        return this.deepCompareBlocks(other.inputBlocks);
    }


    private boolean deepCompareBlocks(int[][] otherBlocks) {
        for (int row = 0; row < this.dimension(); row++) {
            for (int col = 0; col < this.dimension(); col++) {
                if (otherBlocks[row][col] != this.inputBlocks[row][col]) {
                    return false;
                }
            }
        }
        return true;
    }


    /**
     * All neighboring boards: Neighbors are those boards that can be reached in one just move
     */
    public Iterable<Board> neighbors() {

        int size = this.inputBlocks.length;
        Queue<Board> neighborsQueue = new Queue<>();
        if (this.emptyXPosition - 1 >= 0) {
            int[][] newBoardBlocks = this.copyBoard(this.inputBlocks);
            swap(newBoardBlocks, emptyXPosition, emptyYPosition, emptyXPosition - 1, emptyYPosition);
            neighborsQueue.enqueue(new Board(newBoardBlocks));
        }
        if (this.emptyXPosition + 1 < size) {
            int[][] newBoardBlocks = this.copyBoard(this.inputBlocks);
            swap(newBoardBlocks, emptyXPosition, emptyYPosition, emptyXPosition + 1, emptyYPosition);
            neighborsQueue.enqueue(new Board(newBoardBlocks));
        }
        if (this.emptyYPosition - 1 >= 0) {
            int[][] newBoardBlocks = this.copyBoard(this.inputBlocks);
            swap(newBoardBlocks, emptyXPosition, emptyYPosition, emptyXPosition, emptyYPosition - 1);
            neighborsQueue.enqueue(new Board(newBoardBlocks));
        }
        if (this.emptyYPosition + 1 < size) {
            int[][] newBoardBlocks = this.copyBoard(this.inputBlocks);
            swap(newBoardBlocks, emptyXPosition, emptyYPosition, emptyXPosition, emptyYPosition + 1);
            neighborsQueue.enqueue(new Board(newBoardBlocks));
        }
        return neighborsQueue;
    }


    /**
     * String representation of this board
     */
    public String toString() {
        int size = this.inputBlocks.length;
        String outputFormatter = new StringBuilder().append("%").append(size + 1).append("d").toString();
        StringBuilder builder = new StringBuilder();
        builder.append(this.dimension());
        builder.append(System.lineSeparator());

        for (int row = 0; row < dimension(); row++) {
            for (int col = 0; col < dimension(); col++) {
                builder.append(String.format(outputFormatter, this.inputBlocks[row][col]));
            }
            builder.append(System.lineSeparator());
        }
        return builder.toString();
    }

    /**
     * Tester main
     */
    public static void main(String[] args) {

        final int[][] input = new int[][]{
                {1, 5, 2},
                {7, 0, 4},
                {8, 6, 3}

        };

        final int[][] inputTwo = new int[][]{
                {1, 5, 2},
                {7, 0, 4},
                {8, 6, 9}

        };


//        final int[][] input = new int[][]{
//                {1, 0},
//                {2, 3}
//        };


        StdOut.println("Original input");

        printSlots(input);

        Board b = new Board(input);
        int[][] result = b.buildGoalBlocks(input);

        StdOut.println("Expected result");

        printSlots(result);
        StdOut.println("Hamming Function " + b.hamming());
        StdOut.println("Manhattan Function " + b.calculateManhattan());

        StdOut.println("Original Board: " + b);
        Board twin = b.twin();
        StdOut.println("Twin Board: " + twin);
        Iterator<Board> iterator = b.neighbors().iterator();
        StdOut.println("Original Board Neighbors");
        StdOut.println("--------------------------------------------------------------");
        while (iterator.hasNext()) {
            StdOut.println(iterator.next());
        }
        StdOut.println("--------------------------------------------------------------");

        Board anotherBoard = new Board(input);
        StdOut.println("Are boards equal: " + anotherBoard.equals(b));
        StdOut.println("Are boards equal: " + b.equals(anotherBoard));
        StdOut.println("Are boards equal: " + anotherBoard.equals(anotherBoard));
        // StdOut.println("Are boards equal: " + anotherBoard.equals(null));

        Board thirdBoard = new Board(inputTwo);
        StdOut.println("Are boards equal: " + anotherBoard.equals(thirdBoard));
        StdOut.println("Are boards equal: " + anotherBoard.equals(anotherBoard.twin()));


        int[][] inputLast = {
                {1, 2, 3, 4, 5, 6, 7, 8, 9},
                {10, 11, 12, 13, 14, 15, 16, 17, 18},
                {19, 20, 21, 22, 23, 24, 25, 26, 27},
                {28, 29, 30, 31, 32, 33, 34, 35, 36},
                {37, 38, 39, 40, 41, 42, 43, 44, 45},
                {46, 47, 48, 49, 50, 51, 52, 53, 54},
                {55, 56, 57, 58, 59, 60, 61, 62, 63},
                {64, 0, 65, 67, 68, 78, 69, 70, 72},
                {73, 74, 66, 75, 76, 77, 79, 71, 80}
        };

        Board lastboard = new Board(inputLast);
        lastboard.neighbors().forEach((board) -> System.out.println(board));
        StdOut.println("manhattan for last: " + lastboard.manhattan());

    }

    private static void printSlots(int[][] result) {
        for (int row = 0; row < result.length; row++) {
            for (int col = 0; col < result.length; col++) {
                StdOut.print(String.format("%3d", result[row][col]));
            }
            StdOut.println();
        }
        StdOut.println("\n\n\n");
    }

}
