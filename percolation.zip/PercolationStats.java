import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {

    private static final double MULTIPLIER = 1.96;

    private final double[] openSitesFrequency;
    private final double[] confidenceValues = new double[2];

    private double standardMean;
    private double standardDeviation;


    // perform trials independent experiments on an n-by-n grid
    public PercolationStats(int n, int trials) {

        if (n <= 0) {
            throw new IllegalArgumentException("Grid size should be > 0 but is " + n);
        }
        if (trials <= 0) {
            throw new IllegalArgumentException("Trials should be > 1 but is " + trials);
        }
        openSitesFrequency = new double[trials];

        for (int trial = 0; trial < trials; trial++) {
            Percolation percolation = new Percolation(n);
            while (!percolation.percolates()) {
                int randomFirst = StdRandom.uniform(1, n + 1);
                int randomNext = StdRandom.uniform(1, n + 1);
                percolation.open(randomFirst, randomNext);
            }
            openSitesFrequency[trial] = (double) percolation.numberOfOpenSites() / (n * n);
        }

    }

    // sample mean of percolation threshold
    public double mean() {
        standardMean = StdStats.mean(openSitesFrequency);
        return standardMean;
    }

    // sample standard deviation of percolation threshold
    public double stddev() {
        standardDeviation = StdStats.stddev(openSitesFrequency);
        return standardDeviation;
    }

    // low  endpoint of 95% confidence interval
    public double confidenceLo() {
        confidenceValues[0] = this.standardMean - ((MULTIPLIER * standardDeviation) / Math
                .sqrt(openSitesFrequency.length));
        return confidenceValues[0];
    }

    // high endpoint of 95% confidence interval
    public double confidenceHi() {
        confidenceValues[1] = this.standardMean + ((MULTIPLIER * standardDeviation) / Math
                .sqrt(openSitesFrequency.length));
        return confidenceValues[1];
    }


    private void printStats() {
        StdOut.println("mean                      = " + standardMean);
        StdOut.println("stddev                    = " + standardDeviation);
        StdOut.println("95% confidence interval   = [" + confidenceValues[0] +
                               ", " + confidenceValues[1] + "]");
    }


    public static void main(String[] args) {

        if (args.length < 2) {
            throw new IllegalArgumentException(
                    "Expecting gridSize and trialSize as command line args");
        }
        PercolationStats stats = new PercolationStats(Integer.parseInt(args[0]),
                                                      Integer.parseInt(args[1]));
        stats.mean();
        stats.stddev();
        stats.confidenceLo();
        stats.confidenceHi();
        stats.printStats();

    }
}

