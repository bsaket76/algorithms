import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {

    private final int gridSize;
    private final WeightedQuickUnionUF weightedQuickUnionUF;
    private final boolean[][] lattice;

    private int openSites;

    public Percolation(int gridSize) {
        if (gridSize < 1) {
            throw new IllegalArgumentException("Invalid grid size specified " +
                                                       gridSize + " should be > 1");
        }
        this.gridSize = gridSize;
        weightedQuickUnionUF = new WeightedQuickUnionUF((gridSize * gridSize) + 2);
        lattice = new boolean[gridSize][gridSize];
    }

    public void open(int row, int col) {
        validateIndices(row, col);
        row--;
        col--;
        int ufIndexToOpen = xyTo1D(row, col);

        if (!lattice[row][col]) {
            lattice[row][col] = true;
            openSites++;

            // Check virtual top
            if (row == 0) {
                int weightedQuickUFTopIndex = xyTo1D(0, col);
                weightedQuickUnionUF.union(0, weightedQuickUFTopIndex);
                // StdOut.println("\tConnected virtual top 0 and " + weightedQuickUFTopIndex);
            }
            // Check virtual bottom
            if (row == gridSize - 1) {
                int weightedQuickUFBottomIndex = xyTo1D(row, col);
                weightedQuickUnionUF.union((gridSize * gridSize) + 1, weightedQuickUFBottomIndex);
            }
            // Check one up
            if (row > 0 && lattice[row - 1][col]) {
                int oneUpUfIndex = xyTo1D(row - 1, col);
                weightedQuickUnionUF.union(ufIndexToOpen, oneUpUfIndex);
            }
            // Check one down
            if (row < gridSize - 1 && lattice[row + 1][col]) {
                int oneDownUfIndex = xyTo1D(row + 1, col);
                weightedQuickUnionUF.union(ufIndexToOpen, oneDownUfIndex);
            }
            // Check one left
            if (col > 0 && lattice[row][col - 1]) {
                int oneLeftUfIndex = xyTo1D(row, col - 1);
                weightedQuickUnionUF.union(ufIndexToOpen, oneLeftUfIndex);
            }
            // Check one right
            if (col < gridSize - 1 && lattice[row][col + 1]) {
                int oneRightUfIndex = xyTo1D(row, col + 1);
                weightedQuickUnionUF.union(ufIndexToOpen, oneRightUfIndex);
            }
        }
    }

    public boolean isFull(int row, int col) {
        validateIndices(row, col);
        row--;
        col--;
        int weightedQuickUFIndex = xyTo1D(row, col);
        return weightedQuickUnionUF.connected(0, weightedQuickUFIndex);
    }

    public boolean isOpen(int row, int col) {
        validateIndices(row, col);
        row--;
        col--;
        return lattice[row][col];
    }

    public int numberOfOpenSites() {
        return openSites;
    }

    public boolean percolates() {
        // StdOut.println(weightedQuickUnionUF.find(0));
        // StdOut.println(weightedQuickUnionUF.find(gridSize * gridSize + 1));
        // StdOut.println("percolates " + weightedQuickUnionUF.connected(0, gridSize * gridSize + 1));
        return weightedQuickUnionUF.connected(0, gridSize * gridSize + 1);
    }

    private void validateIndices(int row, int column) {
        if (row < 1 || row > gridSize || column < 1 || column > gridSize) {
            throw new IllegalArgumentException(
                    "Invalid index specified [" + row + "][" + column + "] for gridSize "
                            + gridSize);
        }
    }


    private int xyTo1D(int row, int col) {
        return (row * gridSize) + col + 1;
    }

    private void printGrid() {
        for (int row = 0; row < lattice.length; row++) {
            for (int column = 0; column < lattice[row].length; column++) {
                StdOut.print(lattice[row][column] + " ");
            }
            StdOut.println();
        }
    }

    public static void main(String[] args) {

        Percolation percolation = new Percolation(3);
        percolation.open(1, 2);
        percolation.open(2, 2);
        percolation.open(3, 2);
        // StdOut.println("Is Full (1, 2) " + percolation.isFull(1, 2));
        // StdOut.println("Is Full (2, 2) " + percolation.isFull(2, 2));
        // StdOut.println("Is Full (3, 2) " + percolation.isFull(3, 2));
        percolation.printGrid();
        // StdOut.println("\nSystem percolates? " + percolation.percolates());
    }


}
