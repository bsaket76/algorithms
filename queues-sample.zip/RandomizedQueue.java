/* *****************************************************************************
 *  Name: RandomizedQueue.java
 *  Date:
 *  Description:  A randomized queue is similar to a stack or queue, except that
 *  the item removed is chosen uniformly at random from items in the data
 *  structure.
 *
 *  Non-iterator operations:      Constant amortized time (array implementation)
 *  Iterator constructor:         linear in current # of items
 *  Other iterator operations:    Constant worst-case time
 *  Non-iterator memory use:      Linear in current # of items
 *  Memory per iterator:          Linear in current # of items
 *
 **************************************************************************** */


import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class RandomizedQueue<Item> implements Iterable<Item> {

    private Item[] data;
    private int capacity;
    private int tail;

    public RandomizedQueue() {
        data = (Item[]) new Object[2];
        capacity = data.length;
        tail = 0;
    }

    public boolean isEmpty() {
        return tail == 0;
    }

    public int size() {
        return tail;
    }

    public void enqueue(Item item) {
        if (item == null) {
            throw new IllegalArgumentException("Cannot add null to RandomizedQueue");
        }
        // StdOut.println("Enqueuing at pos " + tail);
        if (tail == capacity) {
            resize(2 * capacity);
        }
        data[tail++] = item;
    }

    private void resize(int newMax) {
        // StdOut.println("   Resizing to new size " + newMax + " capacity " + capacity);
        Item[] temp = (Item[]) new Object[newMax];
        for (int i = 0; i < tail; i++) {
            temp[i] = data[i];
        }
        capacity = newMax;
        data = temp;
    }

    public Item dequeue() {
        int lastLocation = tail - 1;
        if (capacity == 0 || lastLocation < 0) {
            throw new NoSuchElementException("Cannot dequeue from an empty RandomizedQueue");
        }
        if (lastLocation == 0) {
            // StdOut.println(" Dequeuing only element");
            Item firstItem = data[lastLocation];
            data[lastLocation] = null;
            tail--;
            return firstItem;
        }
        else {
            int random = StdRandom.uniform(tail);
            // StdOut.println(" Dequeuing random element at " + random + " with tail " + tail + " and lastLocation " + lastLocation);
            swap(random, lastLocation);
            Item randomItemAtTail = data[lastLocation];
            data[lastLocation] = null;
            tail--;
            if (tail > 0 && tail == capacity / 4) {
                // StdOut.println("  resizing with tail " + tail + " and capacity " + capacity
                //                        + " and capacity/4 " + capacity / 4);
                resize(capacity / 2);
            }
            return randomItemAtTail;
        }
    }

    private void swap(int random, int lastLocation) {
        Item randomItem = data[random];
        data[random] = data[lastLocation];
        data[lastLocation] = randomItem;
    }

    public Item sample() {
        if (tail == 0 && data[tail] == null) {
            throw new NoSuchElementException(
                    "Could not execute sample on RandomizedQueue for element " + tail);
        }
        int sampleIndex = StdRandom.uniform(tail);
        if (data == null || capacity == 0 || tail < 0 || sampleIndex < 0) {
            throw new NoSuchElementException(
                    "Could not execute sample on RandomizedQueue for element " + sampleIndex);
        }
        return data[sampleIndex];

    }

    public Iterator<Item> iterator() {
        return new RandomizedQueueIterator();
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("[ ");
        for (Item item : data) {
            builder.append(item + " ");
        }
        builder.append("]");
        return builder.toString();
    }

    private class RandomizedQueueIterator implements Iterator<Item> {

        int head = 0;

        @Override
        public boolean hasNext() {
            return head < tail && tail >= 0;
        }

        @Override
        public Item next() {
            if(hasNext()) {
                return data[head++];
            }
            throw new NoSuchElementException("next cannot be invoked");
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException("remove is not supported for RandomizedQueue");

        }
    }

    private static void testEnqueueWithResize() {
        // StdOut.println("Start testEnqueueWithResize");
        RandomizedQueue<String> randomizedQueue = new RandomizedQueue<>();
        // StdOut.println(" isEmpty: " + randomizedQueue.isEmpty() + " size (expected) 0 "
        //                       + randomizedQueue.size());
        randomizedQueue.enqueue("A");
        randomizedQueue.enqueue("B");
        randomizedQueue.enqueue("C");
        randomizedQueue.enqueue("D");
        randomizedQueue.enqueue("E");
        // StdOut.println(" isEmpty: " + randomizedQueue.isEmpty() + " size (expected) 5 "
        //                       + randomizedQueue.size());
        // StdOut.println(randomizedQueue);
        // StdOut.println("End testEnqueueWithResize\n\n");
        StdOut.println("isEmpty: " + randomizedQueue.isEmpty() + " size " + randomizedQueue.size());
    }


    private static void testEnqueueFollowedByDequeue() {
        // StdOut.println("\n\nStart testEnqueueFollowedByDequeue");
        RandomizedQueue<String> randomizedQueue = new RandomizedQueue<>();
        // StdOut.println(" isEmpty: " + randomizedQueue.isEmpty() + " size (expected) 0 "
        //                       + randomizedQueue.size());
        randomizedQueue.enqueue("A");
        randomizedQueue.dequeue();
        // StdOut.println("   first enqueue/dequeue: " + randomizedQueue);
        randomizedQueue.enqueue("A");
        randomizedQueue.dequeue();
        // StdOut.println("   second enqueue/dequeue: " + randomizedQueue);
        randomizedQueue.enqueue("A");
        randomizedQueue.dequeue();
        // StdOut.println("   third enqueue/dequeue: " + randomizedQueue);
        // StdOut.println(" isEmpty: " + randomizedQueue.isEmpty() + " size (expected) 0 "
        //                       + randomizedQueue.size());
        // StdOut.println("   final: " + randomizedQueue);

        // StdOut.println("End testEnqueueFollowedByDequeue\n\n");
        // StdOut.println("isEmpty: " + randomizedQueue.isEmpty() + " size " + randomizedQueue.size());


    }

    private static void testEdgeCases() {
        RandomizedQueue<String> randomizedQueue = new RandomizedQueue<>();
        try {
            randomizedQueue.dequeue();
        }
        catch (NoSuchElementException ne) {
            StdOut.print(ne.getMessage());
        }
        // StdOut.println("isEmpty: " + randomizedQueue.isEmpty() + " size " + randomizedQueue.size());

    }

    private static void testRandomCalls() {
        RandomizedQueue<String> randomizedQueue = new RandomizedQueue<>();
        randomizedQueue.enqueue("A");
        randomizedQueue.enqueue("B");
        randomizedQueue.enqueue("C");
        randomizedQueue.enqueue("D");

        // StdOut.println(" first sample: " + randomizedQueue.sample());
        // StdOut.println(" second sample: " + randomizedQueue.sample());
        // StdOut.println(" size (expected 4): " + randomizedQueue.size());
        // StdOut.println(" third sample: " + randomizedQueue.sample());
        randomizedQueue.dequeue();
        // StdOut.println(" size (expected 3): " + randomizedQueue.size());
        randomizedQueue.enqueue("99");
        // StdOut.println(" size (expected 4): " + randomizedQueue.size());
        // StdOut.println(randomizedQueue);
        // StdOut.println("isEmpty: " + randomizedQueue.isEmpty() + " size " + randomizedQueue.size());


    }

    private static void testEmptyAndFill() {
        RandomizedQueue<String> rq = new RandomizedQueue<>();
        rq.enqueue("A");
        rq.enqueue("B");
        rq.enqueue("C");
        rq.enqueue("D");
        rq.dequeue();
        // StdOut.println("First dequeue: " + rq.size() + " " + rq);
        rq.dequeue();
        // StdOut.println("Second dequeue: " + rq.size() + " " + rq);
        rq.dequeue();
        // StdOut.println("Third dequeue: " + rq.size() + " " + rq);
        rq.dequeue();
        // StdOut.println("Fourth dequeue: " + rq.size() + " " + rq);

        // StdOut.println("isEmpty: " + rq.isEmpty() + " size " + rq.size());

    }


    private static void testIterator() {
        RandomizedQueue<String> rq = new RandomizedQueue<>();
        rq.enqueue("ABC");
        rq.enqueue("DEF");
        rq.enqueue("GHI");
        StdOut.println(
                " Sample: " + rq.sample() + " Size: " + rq.size() + " isEmpty:  " + rq.isEmpty());
        Iterator<String> rqIterator = rq.iterator();
        while (rqIterator.hasNext()) {
            StdOut.print(rqIterator.next() + " ");
        }
        StdOut.println(
                " Sample: " + rq.sample() + " Size: " + rq.size() + " isEmpty:  " + rq.isEmpty());

        rq.dequeue();
        rq.dequeue();
        rq.dequeue();
        rqIterator = rq.iterator();
        while (rqIterator.hasNext()) {
            StdOut.print(rqIterator.next() + " ");
        }
        StdOut.println(" Size: " + rq.size() + " isEmpty:  " + rq.isEmpty());

        StdOut.println("For loop\n");
        for(int i = 0; i < 10000; i++) {
            rq.enqueue("A"  + i);
        }
        rqIterator = rq.iterator();
        int count = 0;
        while(rqIterator.hasNext()) {
            StdOut.print(rqIterator.next() + " " + count++ + " ");
        }
        StdOut.println();
    }


    private static void testEmpty() {
        RandomizedQueue<String> rq = new RandomizedQueue<>();
        try {
            rq.sample();
        }
        catch (NoSuchElementException ne) {
            StdOut.println(ne.getMessage());
        }
    }


    private static void testSample() {

        RandomizedQueue<String> rq = new RandomizedQueue<>();
        rq.enqueue("A");
        rq.enqueue("C");
        rq.enqueue("E");
        rq.enqueue("F");

        for (int i = 0; i < 100; i++) {
            StdOut.print(rq.sample());
        }
        StdOut.println();

    }


    public static void main(String[] args) {

        // testEnqueueWithResize();
        // testEnqueueFollowedByDequeue();
        // testEdgeCases();
        // testRandomCalls();
        // testEmptyAndFill();
        testIterator();
        // testEmpty();
        // testSample();


    }

}
