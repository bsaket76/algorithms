/* *****************************************************************************
 *  Name: Deque.java
 *  Date:
 *  Description:  A double-ended queue or deque (pronounced deck) is a
 *  generalization of a stack and a queue that supports adding and removing
 *  items from either the front or the back of the data structure
 *
 *  Non-iterator operations:      Constant worst-case time (Linked List)
 *  Iterator constructor:         Constant worst-case time
 *  Other iterator operations:    Constant worst-case time
 *  Non-iterator memory use:      Linear in current # of items (Depends on items)
 *  Memory per iterator:          Constant
 *
 **************************************************************************** */

import edu.princeton.cs.algs4.StdOut;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class Deque<Item> implements Iterable<Item> {

    private int n;
    private Node first;
    private Node last;

    private class Node {
        private Item item;
        private Node next;
        private Node prev;
    }

    public Deque() {
        first = null;
        last = null;
        n = 0;
    }

    public boolean isEmpty() {
        return n == 0;
    }

    public int size() {
        return n;
    }

    public void addFirst(Item item) {
        if (item == null) {
            throw new IllegalArgumentException("Item to be added to Deque cannot be null");
        }
        if (n == 0) {
            first = new Node();
            first.item = item;
            first.prev = null;
            last = first;
        }
        else {
            Node old = first;
            first = new Node();
            first.item = item;
            first.next = old;
            old.prev = first;
            first.prev = null;
        }
        n++;
    }

    public void addLast(Item item) {
        if (item == null) {
            throw new IllegalArgumentException("Item to be added to Deque cannot be null");
        }
        if (n == 0) {
            last = new Node();
            last.item = item;
            first = last;
        }
        else if (n == 1) {
            last = new Node();
            last.item = item;
            first.next = last;
            last.prev = first;
        }
        else if (n > 1) {
            Node old = last;
            last = new Node();
            last.item = item;
            old.next = last;
            last.prev = old;
        }
        n++;
    }

    public Item removeFirst() {
        if (first == null) {
            throw new NoSuchElementException("Unable remove first from empty Deque");
        }
        Node old = first;
        first = first.next;
        if (first != null) {
            first.prev = null;
        }
        n--;
        return old.item;
    }

    public Item removeLast() {
        if (last == null) {
            throw new NoSuchElementException("Unable remove last from empty Deque");
        }
        Node old = last;
        Node oneBeforeLast = last.prev;
        if (oneBeforeLast == null) {
            first = null;
            last = null;
        }
        else {
            oneBeforeLast.next = null;
            last = oneBeforeLast;
        }
        n--;
        return old.item;
    }

    public Iterator<Item> iterator() {
        return new DequeIterator();
    }

    private class DequeIterator implements Iterator<Item> {
        private Node current = first;

        @Override
        public boolean hasNext() {
            return current != null;
        }

        @Override
        public Item next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            Node old = current;
            current = current.next;
            return old.item;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException("DequeIterator does not support remove");
        }
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("[");
        for (Item item : this) {
            stringBuilder.append(item + " ");
        }
        stringBuilder.append("]");
        return stringBuilder.toString();
    }

    private static void testBasicOps() {
        // StdOut.println("Start basic tests");
        Deque<String> deque = new Deque<>();
        deque.addFirst("One");
        deque.addFirst("Two");
        deque.addFirst("Three");
        deque.addLast("Four");
        deque.addLast("Five");
        deque.addFirst("Zero");

        // StdOut.println(deque);
        // StdOut.print("deque size: " + deque.size());
        Iterator<String> iter = deque.iterator();
        while (iter.hasNext()) {
            StdOut.print(" " + iter.next() + " ");
        }
        // StdOut.println();
        // StdOut.println("End basic tests\n\n\n");

    }


    private static void testEdgeCases() {
        // StdOut.println(" Start testEdgeCases ");
        Deque<String> deque = new Deque<>();
        assert (deque.isEmpty());
        assert (0 == deque.size());
        try {
            deque.removeFirst();
        }
        catch (NoSuchElementException ne) {
            // StdOut.println(ne.getMessage());
        }

        try {
            deque.removeLast();
        }
        catch (NoSuchElementException ne) {
            // StdOut.println(ne.getMessage());
        }
        // StdOut.println("End testEdgeCases\n\n\n");
    }

    private static void testRandomCalls() {
        // StdOut.println("   Start testRandomCalls ");
        Deque<String> deque = new Deque<>();
        // StdOut.println("initial size (expected 0) " + deque.size());
        deque.addLast("CC");
        deque.addLast("TT");
        // StdOut.println("size (expected 2) " + deque.size() + " contents: " + deque);
        deque.addLast("MM");
        deque.addFirst("ZZ");
        // StdOut.println("size (expected 4) " + deque.size() + " contents: " + deque);
        deque.addFirst("LL");
        deque.addFirst("NN");
        deque.addLast("OO");
        // StdOut.println("size (expected 7) " + deque.size() + " contents: " + deque);
        // StdOut.println(deque);
        // StdOut.println("   End testRandomCalls\n\n\n");
    }

    private static void testFirstAdd() {
        // StdOut.println("   Start testFirstAdd ");
        Deque<String> deque = new Deque<>();
        // StdOut.println("isEmpty (expected true) " + deque.isEmpty());
        deque.addFirst("A");
        deque.addFirst("U");
        deque.addFirst("M");
        // StdOut.println("isEmpty (expected false) " + deque.isEmpty());
        // StdOut.println("size (expected 3) " + deque.size() + " content: " + deque);
        // StdOut.println("   End testFirstAdd\n\n ");
    }

    private static void testLastAdd() {
        // StdOut.println("   Start testLastAdd ");
        Deque<String> deque = new Deque<>();
        // StdOut.println("isEmpty (expected true) " + deque.isEmpty());
        deque.addLast("GET");
        deque.addLast("SET");
        deque.addLast("GO");
        // StdOut.println("isEmpty (expected false) " + deque.isEmpty());
        // StdOut.println("size (expected 3) " + deque.size() + " content: " + deque);
        // StdOut.println("   End testLastAdd\n\n ");

    }

    private static void testMixedAdd() {
        // StdOut.println("   Start testMixedAdd ");
        Deque<String> deque = new Deque<>();
        // StdOut.println("isEmpty (expected true) " + deque.isEmpty());
        deque.addLast("D");
        deque.addFirst("H");
        deque.addLast("A");
        deque.addFirst("F");
        deque.addLast("I");
        // StdOut.println("isEmpty (expected false) " + deque.isEmpty());
        // StdOut.println("size (expected 5) " + deque.size() + " content: " + deque);
        // StdOut.println("   End testMixedAdd\n\n ");

    }

    private static void testAddRemoveCalls() {
        // StdOut.println("   Start testAddRemoveCalls ");
        Deque<String> deque = new Deque<>();
        // StdOut.println("isEmpty (expected true) " + deque.isEmpty());
        deque.addLast("MM");
        deque.removeLast();
        deque.addFirst("MM");
        deque.removeFirst();
        // StdOut.println("isEmpty (expected true) " + deque.isEmpty());
        // StdOut.println("size (expected 0): " + deque.size() + " content: " + deque);

        deque.addLast("MM");
        // StdOut.println("isEmpty (expected false) " + deque.isEmpty());
        // StdOut.println("size (expected 1): " + deque.size() + " content: " + deque);

        // StdOut.println("   End testAddRemoveCalls\n\n ");

    }


    private static void testEmptyAndFill() {
        Deque<String> rq = new Deque<>();
        rq.addFirst("A");
        rq.addFirst("B");
        rq.addFirst("C");
        rq.addLast("D");
        rq.removeFirst();
        rq.removeLast();
        rq.removeLast();
        rq.removeFirst();
        // StdOut.println(rq.size());
    }

    private static void realTest() {
        Deque<String> deque = new Deque<>();
        // StdOut.println("deque.isEmpty() " + deque.isEmpty() + "  dequee size: " + deque.size()
        //                    + "  dequee: " + deque);
        deque.addLast("AZ");
        deque.addLast("BY");
        // StdOut.println("Dequeue size: " + deque.size());
        deque.removeLast();
        // StdOut.println("deque.isEmpty() " + deque.isEmpty() + "  dequee size: " + deque.size()
        //                      + "  dequee: " + deque);
        deque.removeLast();
        // StdOut.println("deque.isEmpty() " + deque.isEmpty() + "  dequee size: " + deque.size()
        //                    + "  dequee: " + deque);

    }

    public static void main(String[] args) {
        testFirstAdd();
        testLastAdd();
        testMixedAdd();
        testBasicOps();
        testEdgeCases();
        testRandomCalls();
        testAddRemoveCalls();
        testEmptyAndFill();
        realTest();

    }


}
